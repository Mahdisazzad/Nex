package com.additional.nex

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.datastore.preferences.core.emptyPreferences
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import org.videolan.libvlc.util.VLCVideoLayout

fun persist(ctx: Context, u: Uri) {
    runCatching { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs by ctx.store.data.collectAsState(initial = emptyPreferences())
    val dark = when (prefs[K.mode]) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    val accent = Color(prefs[K.accent] ?: ACCENTS[0])
    val scheme = if (dark) darkColorScheme(primary = accent) else lightColorScheme(primary = accent)
    var file by remember { mutableStateOf<Uri?>(null) }
    var showPlayer by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var aod by remember { mutableStateOf(false) }
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { delay(2200); splash = false }

    val openFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            persist(ctx, u)
            if (kindOf(ctx, u) == "media") { Engine.add(Track(u, nameOf(ctx, u)), true); showPlayer = true }
            else { file = u; showPlayer = false }
        }
    }
    val fileName = remember(file) { file?.let { nameOf(ctx, it) } }
    val title = (if (showPlayer) Engine.current?.name else fileName) ?: "NEX"

    MaterialTheme(colorScheme = scheme) {
        Box(Modifier.fillMaxSize().background(scheme.background)) {
            prefs[K.bg]?.let { AsyncImage(it, null, Modifier.fillMaxSize().alpha(0.35f), contentScale = ContentScale.Crop) }
            Scaffold(
                containerColor = Color.Transparent,
                contentColor = scheme.onBackground,
                topBar = {
                    TopAppBar(
                        title = { Text(title, maxLines = 1) },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
                    )
                }
            ) { pad ->
                Column(Modifier.padding(pad).fillMaxSize()) {
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp)) {
                        TextButton({ openFile.launch(arrayOf("*/*")) }) { Text("Open") }
                        if (Engine.queue.isNotEmpty()) TextButton({ showPlayer = true }) { Text("Player") }
                        TextButton({ aod = true }) { Text("AOD") }
                        TextButton({ showSettings = true }) { Text("Theme") }
                    }
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        val f = file
                        if (showPlayer) PlayerScreen()
                        else if (f == null) Text("Tap Open to choose any file", Modifier.align(Alignment.Center))
                        else key(f) {
                            when (kindOf(ctx, f)) {
                                "image" -> AsyncImage(f, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                                "pdf" -> PdfView(f)
                                "text" -> TextView(f)
                                else -> OtherView(f)
                            }
                        }
                    }
                }
            }
            if (aod) Aod(Engine.current?.name ?: title) { aod = false }
            if (showSettings) Settings { showSettings = false }
            if (splash) {
                Column(
                    Modifier.fillMaxSize().background(Color.Black),
                    Arrangement.Center, Alignment.CenterHorizontally
                ) {
                    Image(painterResource(R.drawable.logo), null, Modifier.size(150.dp).clip(CircleShape))
                    Spacer(Modifier.height(16.dp))
                    Text("Nex", color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Bold)
                    Text("made by Additional", color = Color.Gray, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
fun PlayerScreen() {
    val ctx = LocalContext.current
    val add = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list ->
        list.forEach { persist(ctx, it); Engine.add(Track(it, nameOf(ctx, it)), false) }
    }
    Column(Modifier.fillMaxSize()) {
        AndroidView(
            factory = { c -> VLCVideoLayout(c).also { Engine.mp.attachViews(it, null, false, false) } },
            onRelease = { Engine.mp.detachViews() },
            modifier = Modifier.fillMaxWidth().height(220.dp)
        )
        Slider(Engine.pos, { Engine.pos = it; Engine.mp.position = it }, Modifier.padding(horizontal = 8.dp))
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly) {
            TextButton({ Engine.prev() }) { Text("Prev") }
            TextButton({ Engine.toggle() }) { Text(if (Engine.playing) "Pause" else "Play") }
            TextButton({ Engine.next() }) { Text("Next") }
            TextButton({ add.launch(arrayOf("audio/*", "video/*")) }) { Text("Add") }
        }
        LazyColumn(Modifier.weight(1f)) {
            itemsIndexed(Engine.queue) { i, t ->
                Row(Modifier.fillMaxWidth().clickable { Engine.play(i) }.padding(start = 16.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(t.name, Modifier.weight(1f), maxLines = 1,
                        color = if (i == Engine.index) MaterialTheme.colorScheme.primary else Color.Unspecified)
                    TextButton({ Engine.remove(i) }) { Text("✕") }
                }
            }
        }
    }
}
