package com.additional.nex

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import java.io.File
import kotlin.random.Random

data class Track(val uri: Uri, val name: String)

/** One player + queue for the whole app, so playback survives the UI (used by PlaybackService). */
object Engine {
    private var lib: LibVLC? = null
    private var player: MediaPlayer? = null
    val mp: MediaPlayer get() = player!!
    private lateinit var app: Context
    private var fd: ParcelFileDescriptor? = null
    private val main = Handler(Looper.getMainLooper())
    private var pendingSeek = 0f
    private val prefs get() = app.getSharedPreferences("nex", Context.MODE_PRIVATE)

    val queue = mutableStateListOf<Track>()
    var index by mutableIntStateOf(-1)
    var playing by mutableStateOf(false)
    var pos by mutableFloatStateOf(0f)
    var speed by mutableFloatStateOf(1f)
    var shuffle by mutableStateOf(false)
    var repeat by mutableIntStateOf(0)      // 0 off, 1 all, 2 one
    var eq by mutableIntStateOf(-1)         // -1 off
    var sleepMin by mutableIntStateOf(0)
    var scaleIdx by mutableIntStateOf(0)
    var onChange: (() -> Unit)? = null
    val current: Track? get() = queue.getOrNull(index)

    fun init(ctx: Context) {
        if (lib != null) return
        app = ctx.applicationContext
        lib = LibVLC(app)
        player = MediaPlayer(lib).also { p ->
            p.setEventListener { e ->
                when (e.type) {
                    MediaPlayer.Event.PositionChanged -> pos = e.positionChanged
                    MediaPlayer.Event.Playing -> {
                        playing = true
                        if (pendingSeek > 0f) { p.position = pendingSeek; pendingSeek = 0f }
                        onChange?.invoke()
                    }
                    MediaPlayer.Event.Paused -> { playing = false; save(); onChange?.invoke() }
                    MediaPlayer.Event.Stopped -> { playing = false; onChange?.invoke() }
                    MediaPlayer.Event.EndReached -> main.post { finished() }
                }
            }
        }
    }

    private fun save() { current?.let { prefs.edit().putFloat(it.uri.toString(), pos).apply() } }

    private fun finished() {
        current?.let { prefs.edit().putFloat(it.uri.toString(), 0f).apply() }
        when {
            repeat == 2 -> play(index)
            shuffle && queue.size > 1 -> play(randomOther())
            index < queue.lastIndex -> play(index + 1)
            repeat == 1 -> play(0)
            else -> mp.stop()
        }
    }

    private fun randomOther(): Int { var r: Int; do { r = Random.nextInt(queue.size) } while (r == index); return r }

    fun play(i: Int) {
        if (i !in queue.indices) return
        save()
        val t = queue[i]
        val local = t.uri.scheme == "content" || t.uri.scheme == "file"
        val f: ParcelFileDescriptor? = if (local) {
            runCatching { app.contentResolver.openFileDescriptor(t.uri, "r") }.getOrNull() ?: return
        } else null
        val m = if (f != null) Media(lib!!, f.fileDescriptor) else Media(lib!!, t.uri)
        val old = fd
        fd = f
        index = i
        pendingSeek = prefs.getFloat(t.uri.toString(), 0f).let { if (it > 0.95f) 0f else it }
        mp.media = m
        m.release()
        mp.rate = speed
        mp.play()
        old?.close()
        ContextCompat.startForegroundService(app, Intent(app, PlaybackService::class.java))
        onChange?.invoke()
    }

    fun add(t: Track, playNow: Boolean) {
        val existing = queue.indexOfFirst { it.uri == t.uri }
        val at = if (existing >= 0) existing else { queue.add(t); queue.lastIndex }
        if (playNow || index < 0) play(at)
    }

    fun addFolder(ctx: Context, tree: Uri) {
        val dir = DocumentFile.fromTreeUri(ctx, tree) ?: return
        dir.listFiles()
            .filter { val m = it.type ?: ""; m.startsWith("audio/") || m.startsWith("video/") }
            .sortedBy { it.name ?: "" }
            .forEach { add(Track(it.uri, it.name ?: "track"), false) }
    }

    fun toggle() { if (mp.isPlaying) mp.pause() else if (index < 0) play(0) else mp.play() }
    fun next() { if (queue.isNotEmpty()) play(if (shuffle && queue.size > 1) randomOther() else (index + 1) % queue.size) }
    fun prev() { if (queue.isNotEmpty()) play(if (index <= 0) queue.lastIndex else index - 1) }

    fun remove(i: Int) {
        if (i !in queue.indices) return
        if (i == index) {
            mp.stop(); queue.removeAt(i); index = -1
            if (queue.isNotEmpty()) play(i.coerceAtMost(queue.lastIndex))
        } else {
            queue.removeAt(i)
            if (i < index) index--
        }
        onChange?.invoke()
    }

    // ---- VLC-style extras ----
    fun cycleSpeed() {
        val s = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        speed = s[(s.indexOf(speed) + 1) % s.size]
        mp.rate = speed
    }

    fun cycleAudio() {
        val t = mp.audioTracks ?: return
        if (t.isEmpty()) return
        val i = t.indexOfFirst { it.id == mp.audioTrack }
        mp.setAudioTrack(t[(i + 1) % t.size].id)
    }

    fun cycleSubs() {
        val t = mp.spuTracks ?: return
        if (t.isEmpty()) return
        val i = t.indexOfFirst { it.id == mp.spuTrack }
        mp.setSpuTrack(t[(i + 1) % t.size].id)
    }

    fun addSubtitle(ctx: Context, u: Uri) {
        val ext = nameOf(ctx, u).substringAfterLast('.', "srt")
        val f = File(ctx.cacheDir, "sub_${System.currentTimeMillis()}.$ext")
        ctx.contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        mp.addSlave(Media.Slave.Type.Subtitle, Uri.fromFile(f), true)
    }

    fun cycleEq() {
        val n = MediaPlayer.Equalizer.getPresetCount()
        eq = if (eq + 1 >= n) -1 else eq + 1
        mp.setEqualizer(if (eq < 0) null else MediaPlayer.Equalizer.createFromPreset(eq))
    }
    fun eqName(): String = if (eq < 0) "off" else MediaPlayer.Equalizer.getPresetName(eq)

    private val sleepRun = Runnable { if (mp.isPlaying) mp.pause(); sleepMin = 0 }
    fun cycleSleep() {
        val o = listOf(0, 15, 30, 60)
        sleepMin = o[(o.indexOf(sleepMin) + 1) % o.size]
        main.removeCallbacks(sleepRun)
        if (sleepMin > 0) main.postDelayed(sleepRun, sleepMin * 60_000L)
    }

    fun cycleScale() {
        val v = MediaPlayer.ScaleType.values()
        scaleIdx = (scaleIdx + 1) % v.size
        mp.setVideoScale(v[scaleIdx])
    }
    fun scaleName(): String = MediaPlayer.ScaleType.values()[scaleIdx].name.removePrefix("SURFACE_")
}
