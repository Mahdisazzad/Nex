package com.additional.nex

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer

data class Track(val uri: Uri, val name: String)

/** One player + queue for the whole app, so playback survives the UI (used by PlaybackService). */
object Engine {
    private var lib: LibVLC? = null
    private var player: MediaPlayer? = null
    val mp: MediaPlayer get() = player!!
    private lateinit var app: Context
    private var fd: ParcelFileDescriptor? = null

    val queue = mutableStateListOf<Track>()
    var index by mutableIntStateOf(-1)
    var playing by mutableStateOf(false)
    var pos by mutableFloatStateOf(0f)
    var onChange: (() -> Unit)? = null
    val current: Track? get() = queue.getOrNull(index)

    fun init(ctx: Context) {
        if (lib != null) return
        app = ctx.applicationContext
        lib = LibVLC(app)
        player = MediaPlayer(lib).also { p ->
            p.setEventListener { e ->
                when (e.type) {
                    MediaPlayer.Event.PositionChanged -> pos = e.positionChanged
                    MediaPlayer.Event.Playing -> { playing = true; onChange?.invoke() }
                    MediaPlayer.Event.Paused, MediaPlayer.Event.Stopped -> { playing = false; onChange?.invoke() }
                    MediaPlayer.Event.EndReached -> Handler(Looper.getMainLooper()).post {
                        if (index < queue.lastIndex) play(index + 1) else mp.stop()
                    }
                }
            }
        }
    }

    fun play(i: Int) {
        if (i !in queue.indices) return
        val f = runCatching { app.contentResolver.openFileDescriptor(queue[i].uri, "r") }.getOrNull() ?: return
        val old = fd
        fd = f
        index = i
        val m = Media(lib!!, f.fileDescriptor)
        mp.media = m
        m.release()
        mp.play()
        old?.close()
        ContextCompat.startForegroundService(app, Intent(app, PlaybackService::class.java))
        onChange?.invoke()
    }

    fun add(t: Track, playNow: Boolean) {
        val existing = queue.indexOfFirst { it.uri == t.uri }
        val at = if (existing >= 0) existing else { queue.add(t); queue.lastIndex }
        if (playNow || index < 0) play(at)
    }

    fun toggle() { if (mp.isPlaying) mp.pause() else if (index < 0) play(0) else mp.play() }
    fun next() { if (queue.isNotEmpty()) play((index + 1) % queue.size) }
    fun prev() { if (queue.isNotEmpty()) play(if (index <= 0) queue.lastIndex else index - 1) }

    fun remove(i: Int) {
        if (i !in queue.indices) return
        if (i == index) {
            mp.stop(); queue.removeAt(i); index = -1
            if (queue.isNotEmpty()) play(i.coerceAtMost(queue.lastIndex))
        } else {
            queue.removeAt(i)
            if (i < index) index--
        }
        onChange?.invoke()
    }
}
