package com.additional.nex

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val Context.store by preferencesDataStore("settings")

object K {
    val mode = stringPreferencesKey("mode")   // system | light | dark
    val accent = intPreferencesKey("accent")
    val bg = stringPreferencesKey("bg")
}

val ACCENTS = listOf(0xFF6650A4.toInt(), 0xFFE91E63.toInt(), 0xFF009688.toInt(), 0xFFFF9800.toInt(), 0xFF2196F3.toInt())
val MEDIA_EXT = setOf("mp3", "flac", "wav", "ogg", "m4a", "aac", "opus", "wma", "mp4", "mkv", "avi", "mov", "webm", "flv", "wmv", "3gp", "m4v")
val TEXT_EXT = setOf("txt", "md", "json", "xml", "html", "css", "js", "ts", "kt", "kts", "java", "py", "c", "cpp", "h", "cs", "go", "rs", "php", "rb", "sh", "yml", "yaml", "toml", "ini", "csv", "log", "sql", "swift", "gradle")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Engine.init(this)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { App() }
    }
}

fun nameOf(ctx: Context, uri: Uri): String =
    ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
        ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: uri.lastPathSegment ?: "file"

fun kindOf(ctx: Context, uri: Uri): String {
    val mime = ctx.contentResolver.getType(uri) ?: ""
    val ext = nameOf(ctx, uri).substringAfterLast('.', "").lowercase()
    return when {
        mime.startsWith("image/") -> "image"
        mime.startsWith("audio/") || mime.startsWith("video/") || ext in MEDIA_EXT -> "media"
        mime == "application/pdf" || ext == "pdf" -> "pdf"
        mime.startsWith("text/") || ext in TEXT_EXT -> "text"
        else -> "other"
    }
}

@Composable
fun PdfView(uri: Uri) {
    val ctx = LocalContext.current
    val fd = remember(uri) { ctx.contentResolver.openFileDescriptor(uri, "r")!! }
    val renderer = remember(uri) { PdfRenderer(fd) }
    val lock = remember { Mutex() }   // PdfRenderer allows one open page at a time
    DisposableEffect(uri) { onDispose { renderer.close(); fd.close() } }

    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(renderer.pageCount) { i ->
            val bmp by produceState<Bitmap?>(null, i) {
                value = lock.withLock {
                    withContext(Dispatchers.IO) {
                        renderer.openPage(i).use { p ->
                            val w = 1080
                            Bitmap.createBitmap(w, w * p.height / p.width, Bitmap.Config.ARGB_8888).also {
                                it.eraseColor(0xFFFFFFFF.toInt())
                                p.render(it, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            }
                        }
                    }
                }
            }
            bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth) }
        }
    }
}

@Composable
fun TextView(uri: Uri) {
    val ctx = LocalContext.current
    val text by produceState("Loading…", uri) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                ctx.contentResolver.openInputStream(uri)!!.bufferedReader().use { r ->
                    val buf = CharArray(500_000)
                    String(buf, 0, maxOf(r.read(buf), 0))
                }
            }.getOrElse { "Couldn't read this file." }
        }
    }
    val lines = remember(text) { text.lines() }
    Box(Modifier.fillMaxSize().horizontalScroll(rememberScrollState())) {
        LazyColumn(Modifier.padding(8.dp)) {
            items(lines) { Text(it, fontFamily = FontFamily.Monospace, fontSize = 13.sp, softWrap = false) }
        }
    }
}

@Composable
fun OtherView(uri: Uri) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("No built-in preview for this file type.")
        Button({
            val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, ctx.contentResolver.getType(uri) ?: "*/*")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            try { ctx.startActivity(Intent.createChooser(i, "Open with")) } catch (_: ActivityNotFoundException) {}
        }, Modifier.padding(top = 16.dp)) { Text("Open with another app") }
    }
}

@Composable
fun Aod(title: String, onExit: () -> Unit) {
    val window = (LocalContext.current as ComponentActivity).window
    DisposableEffect(Unit) {
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.apply { screenBrightness = 0.05f }
        onDispose {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            window.attributes = window.attributes.apply { screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE }
        }
    }
    var tick by remember { mutableIntStateOf(0) }
    var time by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (true) {
            time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            tick++
            delay(30_000)
        }
    }
    // pixel shift every 30s to prevent OLED burn-in
    Box(Modifier.fillMaxSize().background(Color.Black).clickable { onExit() }, Alignment.Center) {
        Column(Modifier.offset(((tick * 37) % 60 - 30).dp, ((tick * 53) % 80 - 40).dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(time, color = Color.White.copy(alpha = 0.7f), fontSize = 64.sp)
            Text(title, color = Color.Gray, fontSize = 16.sp, maxLines = 1)
        }
    }
}

@Composable
fun Settings(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    fun <T> put(k: Preferences.Key<T>, v: T) { scope.launch { ctx.store.edit { it[k] = v } } }
    val pickBg = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            put(K.bg, u.toString())
        }
    }
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClose) { Text("Done") } },
        title = { Text("Appearance") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row { listOf("system", "light", "dark").forEach { m -> TextButton({ put(K.mode, m) }) { Text(m.replaceFirstChar { it.uppercase() }) } } }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ACCENTS.forEach { c -> Box(Modifier.size(36.dp).clip(CircleShape).background(Color(c)).clickable { put(K.accent, c) }) }
                }
                Row {
                    TextButton({ pickBg.launch(arrayOf("image/*")) }) { Text("Background") }
                    TextButton({ scope.launch { ctx.store.edit { it.remove(K.bg) } } }) { Text("Remove") }
                }
            }
        }
    )
}
