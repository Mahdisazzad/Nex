package com.additional.nex

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.drawable.Icon
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.IBinder
import android.os.PowerManager

/** Foreground service: keeps audio playing with the screen off and shows notification controls. */
class PlaybackService : Service() {
    private lateinit var session: MediaSession
    private lateinit var wake: PowerManager.WakeLock
    private var closing = false
    private val logo by lazy { BitmapFactory.decodeResource(resources, R.drawable.logo) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "Playback", NotificationManager.IMPORTANCE_LOW))
        session = MediaSession(this, "NEX").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() { if (!Engine.playing) Engine.toggle() }
                override fun onPause() { if (Engine.playing) Engine.toggle() }
                override fun onSkipToNext() { Engine.next() }
                override fun onSkipToPrevious() { Engine.prev() }
            })
            isActive = true
        }
        wake = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nex:play")
        wake.acquire()
        Engine.onChange = { refresh() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "toggle" -> Engine.toggle()
            "next" -> Engine.next()
            "prev" -> Engine.prev()
            "stop" -> {
                closing = true
                Engine.mp.stop()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
        }
        updateSession()
        startForeground(ID, build())
        return START_NOT_STICKY
    }

    private fun refresh() {
        if (closing) return
        if (Engine.current == null) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return }
        updateSession()
        getSystemService(NotificationManager::class.java).notify(ID, build())
    }

    private fun updateSession() {
        session.setMetadata(MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE, Engine.current?.name ?: "NEX").build())
        session.setPlaybackState(
            PlaybackState.Builder()
                .setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                        PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS)
                .setState(if (Engine.playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                    PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1f)
                .build()
        )
    }

    private fun act(icon: Int, label: String, action: String) = Notification.Action.Builder(
        Icon.createWithResource(this, icon), label,
        PendingIntent.getService(this, action.hashCode(), Intent(this, PlaybackService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    ).build()

    private fun build(): Notification {
        val open = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setLargeIcon(logo)
            .setContentTitle(Engine.current?.name ?: "NEX")
            .setContentText("NEX")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(act(android.R.drawable.ic_media_previous, "Previous", "prev"))
            .addAction(act(if (Engine.playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play, "Play/Pause", "toggle"))
            .addAction(act(android.R.drawable.ic_media_next, "Next", "next"))
            .addAction(act(android.R.drawable.ic_menu_close_clear_cancel, "Close", "stop"))
            .setStyle(Notification.MediaStyle().setMediaSession(session.sessionToken).setShowActionsInCompactView(0, 1, 2))
            .build()
    }

    override fun onDestroy() {
        Engine.onChange = null
        if (wake.isHeld) wake.release()
        session.release()
        super.onDestroy()
    }

    companion object { const val CH = "nex_playback"; const val ID = 1 }
}
